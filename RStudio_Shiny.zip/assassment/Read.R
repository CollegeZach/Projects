library(ggplot2)
library(magrittr)
library(dplyr)
grades <- read.csv("data/nyuclasses.csv")
head(grades)

subgrades <- grades %>% filter(assessment == "Assignment 1")
?filter
assigns <- unique(grades$assessment)

assigns

assign <- "Assignment 1"

ggplot(subgrades, aes(x = factor(assessment), y = score)) + geom_boxplot()

head(subgrades)

#getwd()
