library(readr)
library(shiny)
library(stringr)
library(dplyr)
library(tidyverse)

nyuclasses <- read_csv("data/nyuclasses.csv")
unique(grades$assessment)

#nyuclasses <- nyuclasses %>% filter(str_detect(assessment, "Assignment"))
#nyuclasses <- nyuclasses %>% drop_na("score")
#nyuclasses$assessment <- as.factor(nyuclasses$assessment)

#source("helpers.R")
#counties <- readRDS(file = "data/counties.rds")

ui <- fluidPage(
  titlePanel("Assessment Dashboard"),
  
  sidebarLayout(
    sidebarPanel(
      selectInput("assign",
                  label = "Chosse an Assignment",
                  choices = unique(grades$assessment),
                  selected = "Assignment 1")
      ),
    
    mainPanel(
      plotOutput("gradePlot")

    )
  )
)

server <- function(input, output) {
  output$gradePlot <- renderPlot( {
    grades <- nyuclasses %>% filter(assessment == input$assign)
    ggplot(grades, aes(x=factor(assessment), y=score)) + geom_boxplot()
    #grade_ad = input$assessment
    #boxplot(nyuclasses$score[nyuclasses$assessment==grade_ad], frame.plot=FALSE, horizontal=TRUE, col="magenta", main="grade_ad")
    })
}

# Create Shiny app
shinyApp(ui = ui, server = server)
