﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace StateGame
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Random randomNumber = new Random();

        int stateCapital, capital1, capital2, capital3, decider;
        string stateName, capitalName, random1, random2, random3;
        int winStreak = 0;

        public MainWindow()
        {
            InitializeComponent();
        }

        private void startGame(object sender, RoutedEventArgs e)
        {
            lblCheckAnswer.Content = "";
            PlayGame.Content = "";

            Guess1.IsEnabled = true;
            Guess2.IsEnabled = true;
            Guess3.IsEnabled = true;
            Guess4.IsEnabled = true;

            stateCapital = randomNumber.Next(1, 50);
            switch (stateCapital)
            {
                case 1:
                    stateName = "Alabama";
                    capitalName = "Montgomery";
                    break;
                case 2:
                    stateName = "Alaska";
                    capitalName = "Juneau";
                    break;
                case 3:
                    stateName = "Arizona";
                    capitalName = "Phoenix";
                    break;
                case 4:
                    stateName = "Arkansas";
                    capitalName = "Little Rock";
                    break;
                case 5:
                    stateName = "California";
                    capitalName = "Sacramento";
                    break;
                case 6:
                    stateName = "Colorado";
                    capitalName = "Denver";
                    break;
                case 7:
                    stateName = "Connecticut";
                    capitalName = "Hartford";
                    break;
                case 8:
                    stateName = "Delaware";
                    capitalName = "Dover";
                    break;
                case 9:
                    stateName = "Florida";
                    capitalName = "Tallahassee";
                    break;
                case 10:
                    stateName = "Georgia";
                    capitalName = "Atlanta";
                    break;
                case 11:
                    stateName = "Hawaii";
                    capitalName = "Honolulu";
                    break;
                case 12:
                    stateName = "Idaho";
                    capitalName = "Boise";
                    break;
                case 13:
                    stateName = "Illinois";
                    capitalName = "Springfield";
                    break;
                case 14:
                    stateName = "Indiana";
                    capitalName = "Indianapolis";
                    break;
                case 15:
                    stateName = "Iowa";
                    capitalName = "Des Moines";
                    break;
                case 16:
                    stateName = "Kansas";
                    capitalName = "Topeka";
                    break;
                case 17:
                    stateName = "Kentucky";
                    capitalName = "Frankfort";
                    break;
                case 18:
                    stateName = "Louisiana";
                    capitalName = "Baton Rouge";
                    break;
                case 19:
                    stateName = "Maine";
                    capitalName = "Augusta";
                    break;
                case 20:
                    stateName = "Maryland";
                    capitalName = "Annapolis";
                    break;
                case 21:
                    stateName = "Massachusetts";
                    capitalName = "Boston";
                    break;
                case 22:
                    stateName = "Michigan";
                    capitalName = "Lansing";
                    break;
                case 23:
                    stateName = "Minnesota";
                    capitalName = "Saint Paul";
                    break;
                case 24:
                    stateName = "Mississippi";
                    capitalName = "Jackson";
                    break;
                case 25:
                    stateName = "Missouri";
                    capitalName = "Jefferson City";
                    break;
                case 26:
                    stateName = "Montana";
                    capitalName = "Helena";
                    break;
                case 27:
                    stateName = "Nebraska";
                    capitalName = "Lincoln";
                    break;
                case 28:
                    stateName = "Nevada";
                    capitalName = "Carson City";
                    break;
                case 29:
                    stateName = "New Hampshire";
                    capitalName = "Concord";
                    break;
                case 30:
                    stateName = "New Jersey";
                    capitalName = "Trenton";
                    break;
                case 31:
                    stateName = "New Mexico";
                    capitalName = "Santa Fe";
                    break;
                case 32:
                    stateName = "New York";
                    capitalName = "Albany";
                    break;
                case 33:
                    stateName = "North Carolina";
                    capitalName = "Raleign";
                    break;
                case 34:
                    stateName = "North Dakota";
                    capitalName = "Bismarck";
                    break;
                case 35:
                    stateName = "Ohio";
                    capitalName = "Columbus";
                    break;
                case 36:
                    stateName = "Oklahoma";
                    capitalName = "Oklahoma City";
                    break;
                case 37:
                    stateName = "Oregon";
                    capitalName = "Salem";
                    break;
                case 38:
                    stateName = "Pennsylvania";
                    capitalName = "Harrisburg";
                    break;
                case 39:
                    stateName = "Rhode Island";
                    capitalName = "Providence";
                    break;
                case 40:
                    stateName = "South Carolina";
                    capitalName = "Columbia";
                    break;
                case 41:
                    stateName = "South Dakota";
                    capitalName = "Pierre";
                    break;
                case 42:
                    stateName = "Tennessee";
                    capitalName = "Nashville";
                    break;
                case 43:
                    stateName = "Texas";
                    capitalName = "Austin";
                    break;
                case 44:
                    stateName = "Utah";
                    capitalName = "Salt Lake City";
                    break;
                case 45:
                    stateName = "Vermont";
                    capitalName = "Montpelier";
                    break;
                case 46:
                    stateName = "Virginia";
                    capitalName = "Richmond";
                    break;
                case 47:
                    stateName = "Washington";
                    capitalName = "Olympia";
                    break;
                case 48:
                    stateName = "West Virginia";
                    capitalName = "Charleston";
                    break;
                case 49:
                    stateName = "Wisconsin";
                    capitalName = "Madison";
                    break;
                case 50:
                    stateName = "Wyoming";
                    capitalName = "Cheyenne";
                    break;
            }
            lblStateName.Content = stateName;

            capital1 = randomNumber.Next(1, 50);
            capital2 = randomNumber.Next(1, 50);
            capital3 = randomNumber.Next(1, 50);
            switch (capital1)
            {
                case 1:
                    random1 = "Montgomery";
                    break;
                case 2:
                    random1 = "Juneau";
                    break;
                case 3:
                    random1 = "Phoenix";
                    break;
                case 4:
                    random1 = "Little Rock";
                    break;
                case 5:
                    random1 = "Sacramento";
                    break;
                case 6:
                    random1 = "Denver";
                    break;
                case 7:
                    random1 = "Hartford";
                    break;
                case 8:
                    random1 = "Dover";
                    break;
                case 9:
                    random1 = "Tallahassee";
                    break;
                case 10:
                    random1 = "Atlanta";
                    break;
                case 11:
                    random1 = "Honolulu";
                    break;
                case 12:
                    random1 = "Boise";
                    break;
                case 13:
                    random1 = "Springfield";
                    break;
                case 14:
                    random1 = "Indianapolis";
                    break;
                case 15:
                    random1 = "Des Moines";
                    break;
                case 16:
                    random1 = "Topeka";
                    break;
                case 17:
                    random1 = "Frankfort";
                    break;
                case 18:
                    random1 = "Baton Rouge";
                    break;
                case 19:
                    random1 = "Augusta";
                    break;
                case 20:
                    random1 = "Annapolis";
                    break;
                case 21:
                    random1 = "Boston";
                    break;
                case 22:
                    random1 = "Lansing";
                    break;
                case 23:
                    random1 = "Saint Paul";
                    break;
                case 24:
                    random1 = "Jackson";
                    break;
                case 25:
                    random1 = "Jefferson City";
                    break;
                case 26:
                    random1 = "Helena";
                    break;
                case 27:
                    random1 = "Lincoln";
                    break;
                case 28:
                    random1 = "Carson City";
                    break;
                case 29:
                    random1 = "Concord";
                    break;
                case 30:
                    random1 = "Trenton";
                    break;
                case 31:
                    random1 = "Santa Fe";
                    break;
                case 32:
                    random1 = "Albany";
                    break;
                case 33:
                    random1 = "Raleign";
                    break;
                case 34:
                    random1 = "Bismarck";
                    break;
                case 35:
                    random1 = "Columbus";
                    break;
                case 36:
                    random1 = "Oklahoma City";
                    break;
                case 37:
                    random1 = "Salem";
                    break;
                case 38:
                    random1 = "Harrisburg";
                    break;
                case 39:
                    random1 = "Providence";
                    break;
                case 40:
                    random1 = "Columbia";
                    break;
                case 41:
                    random1 = "Pierre";
                    break;
                case 42:
                    random1 = "Nashville";
                    break;
                case 43:
                    random1 = "Austin";
                    break;
                case 44:
                    random1 = "Salt Lake City";
                    break;
                case 45:
                    random1 = "Montpelier";
                    break;
                case 46:
                    random1 = "Richmond";
                    break;
                case 47:
                    random1 = "Olympia";
                    break;
                case 48:
                    random1 = "Charleston";
                    break;
                case 49:
                    random1 = "Madison";
                    break;
                case 50:
                    random1 = "Cheyenne";
                    break;
            }
            switch (capital2)
            {
                case 1:
                    random2 = "Montgomery";
                    break;
                case 2:
                    random2 = "Juneau";
                    break;
                case 3:
                    random2 = "Phoenix";
                    break;
                case 4:
                    random2 = "Little Rock";
                    break;
                case 5:
                    random2 = "Sacramento";
                    break;
                case 6:
                    random2 = "Denver";
                    break;
                case 7:
                    random2 = "Hartford";
                    break;
                case 8:
                    random2 = "Dover";
                    break;
                case 9:
                    random2 = "Tallahassee";
                    break;
                case 10:
                    random2 = "Atlanta";
                    break;
                case 11:
                    random2 = "Honolulu";
                    break;
                case 12:
                    random2 = "Boise";
                    break;
                case 13:
                    random2 = "Springfield";
                    break;
                case 14:
                    random2 = "Indianapolis";
                    break;
                case 15:
                    random2 = "Des Moines";
                    break;
                case 16:
                    random2 = "Topeka";
                    break;
                case 17:
                    random2 = "Frankfort";
                    break;
                case 18:
                    random2 = "Baton Rouge";
                    break;
                case 19:
                    random2 = "Augusta";
                    break;
                case 20:
                    random2 = "Annapolis";
                    break;
                case 21:
                    random2 = "Boston";
                    break;
                case 22:
                    random2 = "Lansing";
                    break;
                case 23:
                    random2 = "Saint Paul";
                    break;
                case 24:
                    random2 = "Jackson";
                    break;
                case 25:
                    random2 = "Jefferson City";
                    break;
                case 26:
                    random2 = "Helena";
                    break;
                case 27:
                    random2 = "Lincoln";
                    break;
                case 28:
                    random2 = "Carson City";
                    break;
                case 29:
                    random2 = "Concord";
                    break;
                case 30:
                    random2 = "Trenton";
                    break;
                case 31:
                    random2 = "Santa Fe";
                    break;
                case 32:
                    random2 = "Albany";
                    break;
                case 33:
                    random2 = "Raleign";
                    break;
                case 34:
                    random2 = "Bismarck";
                    break;
                case 35:
                    random2 = "Columbus";
                    break;
                case 36:
                    random2 = "Oklahoma City";
                    break;
                case 37:
                    random2 = "Salem";
                    break;
                case 38:
                    random2 = "Harrisburg";
                    break;
                case 39:
                    random2 = "Providence";
                    break;
                case 40:
                    random2 = "Columbia";
                    break;
                case 41:
                    random2 = "Pierre";
                    break;
                case 42:
                    random2 = "Nashville";
                    break;
                case 43:
                    random2 = "Austin";
                    break;
                case 44:
                    random2 = "Salt Lake City";
                    break;
                case 45:
                    random2 = "Montpelier";
                    break;
                case 46:
                    random2 = "Richmond";
                    break;
                case 47:
                    random2 = "Olympia";
                    break;
                case 48:
                    random2 = "Charleston";
                    break;
                case 49:
                    random2 = "Madison";
                    break;
                case 50:
                    random2 = "Cheyenne";
                    break;
            }
            switch (capital3)
            {
                case 1:
                    random3 = "Montgomery";
                    break;
                case 2:
                    random3 = "Juneau";
                    break;
                case 3:
                    random3 = "Phoenix";
                    break;
                case 4:
                    random3 = "Little Rock";
                    break;
                case 5:
                    random3 = "Sacramento";
                    break;
                case 6:
                    random3 = "Denver";
                    break;
                case 7:
                    random3 = "Hartford";
                    break;
                case 8:
                    random3 = "Dover";
                    break;
                case 9:
                    random3 = "Tallahassee";
                    break;
                case 10:
                    random3 = "Atlanta";
                    break;
                case 11:
                    random3 = "Honolulu";
                    break;
                case 12:
                    random3 = "Boise";
                    break;
                case 13:
                    random3 = "Springfield";
                    break;
                case 14:
                    random3 = "Indianapolis";
                    break;
                case 15:
                    random3 = "Des Moines";
                    break;
                case 16:
                    random3 = "Topeka";
                    break;
                case 17:
                    random3 = "Frankfort";
                    break;
                case 18:
                    random3 = "Baton Rouge";
                    break;
                case 19:
                    random3 = "Augusta";
                    break;
                case 20:
                    random3 = "Annapolis";
                    break;
                case 21:
                    random3 = "Boston";
                    break;
                case 22:
                    random3 = "Lansing";
                    break;
                case 23:
                    random3 = "Saint Paul";
                    break;
                case 24:
                    random3 = "Jackson";
                    break;
                case 25:
                    random3 = "Jefferson City";
                    break;
                case 26:
                    random3 = "Helena";
                    break;
                case 27:
                    random3 = "Lincoln";
                    break;
                case 28:
                    random3 = "Carson City";
                    break;
                case 29:
                    random3 = "Concord";
                    break;
                case 30:
                    random3 = "Trenton";
                    break;
                case 31:
                    random3 = "Santa Fe";
                    break;
                case 32:
                    random3 = "Albany";
                    break;
                case 33:
                    random3 = "Raleign";
                    break;
                case 34:
                    random3 = "Bismarck";
                    break;
                case 35:
                    random3 = "Columbus";
                    break;
                case 36:
                    random3 = "Oklahoma City";
                    break;
                case 37:
                    random3 = "Salem";
                    break;
                case 38:
                    random3 = "Harrisburg";
                    break;
                case 39:
                    random3 = "Providence";
                    break;
                case 40:
                    random3 = "Columbia";
                    break;
                case 41:
                    random3 = "Pierre";
                    break;
                case 42:
                    random3 = "Nashville";
                    break;
                case 43:
                    random3 = "Austin";
                    break;
                case 44:
                    random3 = "Salt Lake City";
                    break;
                case 45:
                    random3 = "Montpelier";
                    break;
                case 46:
                    random3 = "Richmond";
                    break;
                case 47:
                    random3 = "Olympia";
                    break;
                case 48:
                    random3 = "Charleston";
                    break;
                case 49:
                    random3 = "Madison";
                    break;
                case 50:
                    random3 = "Cheyenne";
                    break;
            }

            decider = randomNumber.Next(1, 4);
            switch (decider)
            {
                case 1:
                    Guess1.Content = capitalName;
                    Guess2.Content = random1;
                    Guess3.Content = random2;
                    Guess4.Content = random3;
                    break;
                case 2:
                    Guess1.Content = random1;
                    Guess2.Content = capitalName;
                    Guess3.Content = random2;
                    Guess4.Content = random3;
                    break;
                case 3:
                    Guess1.Content = random1;
                    Guess2.Content = random2;
                    Guess3.Content = capitalName;
                    Guess4.Content = random3;
                    break;
                case 4:
                    Guess1.Content = random1;
                    Guess2.Content = random2;
                    Guess3.Content = random3;
                    Guess4.Content = capitalName;
                    break;
            }

            //BitMapImage

            //showState.Source("PA-Pennsylvania.png");

        }

        private void Option1(object sender, RoutedEventArgs e)
        {
            if(Guess1.Content == capitalName)
            {
                lblCheckAnswer.Content = "Correct";
                winStreak = winStreak + 1;
                streak.Content = winStreak;

                Guess1.IsEnabled = false;
                Guess2.IsEnabled = false;
                Guess3.IsEnabled = false;
                Guess4.IsEnabled = false;
            }
            else
            {
                lblCheckAnswer.Content = "Try Again";
                winStreak = 0;
                streak.Content = winStreak;
            }

            PlayGame.Content = "Refresh";
        }
        private void Option2(object sender, RoutedEventArgs e)
        {
            if (Guess2.Content == capitalName)
            {
                lblCheckAnswer.Content = "Correct";
                winStreak = winStreak + 1;
                streak.Content = winStreak;

                Guess1.IsEnabled = false;
                Guess2.IsEnabled = false;
                Guess3.IsEnabled = false;
                Guess4.IsEnabled = false;
            }
            else
            {
                lblCheckAnswer.Content = "Try Again";
                winStreak = 0;
                streak.Content = winStreak;
            }

            PlayGame.Content = "Refresh";
        }
        private void Option3(object sender, RoutedEventArgs e)
        {
            if (Guess3.Content == capitalName)
            {
                lblCheckAnswer.Content = "Correct";
                winStreak = winStreak + 1;
                streak.Content = winStreak;

                Guess1.IsEnabled = false;
                Guess2.IsEnabled = false;
                Guess3.IsEnabled = false;
                Guess4.IsEnabled = false;
            }
            else
            {
                lblCheckAnswer.Content = "Try Again";
                winStreak = 0;
                streak.Content = winStreak;
            }

            PlayGame.Content = "Refresh";
        }
        private void Option4(object sender, RoutedEventArgs e)
        {
            if (Guess4.Content == capitalName)
            {
                lblCheckAnswer.Content = "Correct";
                winStreak = winStreak + 1;
                streak.Content = winStreak;

                Guess1.IsEnabled = false;
                Guess2.IsEnabled = false;
                Guess3.IsEnabled = false;
                Guess4.IsEnabled = false;
            }
            else
            {
                lblCheckAnswer.Content = "Try Again";
                winStreak = 0;
                streak.Content = winStreak;
            }

            PlayGame.Content = "Refresh";
        }

    }
}
