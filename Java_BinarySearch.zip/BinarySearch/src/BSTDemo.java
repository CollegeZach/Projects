
public class BSTDemo {
	
	public static void main(String[] args) {
		
		BST<String, String> contacts = new BST<String, String>();
		
		contacts.insert("Joe", "12 Elm");
		contacts.insert("Sue", "121 Oak");
		contacts.insert("Dale", "19 Cherry");
		contacts.insert("Sam", "90 Maple");
		contacts.insert("Jane", "33 Walnut");
		contacts.insert("Erin", "22 Ash");
		
		System.out.println(contacts.size());
		
		contacts.inOrder();
		System.out.println();
		contacts.preOrder();
		System.out.println();
		contacts.postOrder();
	}
	
}
