import java.util.LinkedList;

public class BST <Key extends Comparable<Key>, Value>{
	
	private Node root;
	
	//Constructor
	public BST() {
		root = null;
	}
	
	public void levelOrder() {
		levelOrderHelper(root);
	}
	
	//visit the node in an in-order
	private void levelOrderHelper(Node n) {
		java.util.Queue<Key> que = new LinkedList<Key>();
		if(root == null)
			return;
		que.add(n.key);
		
		Key temp;
		while(!que.isEmpty()) {
			temp = que.remove();
			if(temp == null)
				continue;
			if(temp)
		}
		
	}
	
	public void postOrder() {
		postOrderHelper(root);
	}
	
	//visit the node in an post-order
	private void postOrderHelper(Node n) {
		if(n == null)
			return;
		postOrderHelper(n.left);
		postOrderHelper(n.right);
		System.out.println(n.key);
	}
	
	public void preOrder() {
		preOrderHelper(root);
	}
	
	//visit the node in an pre-order
	private void preOrderHelper(Node n) {
		if(n == null)
			return;
		System.out.println(n.key);
		preOrderHelper(n.left);
		preOrderHelper(n.right);
	}
	
	public void inOrder() {
		inOrderHelper(root);
	}
	
	//visit the node in an in-order
	private void inOrderHelper(Node n) {
		if(n == null)
			return;
		inOrderHelper(n.left);
		System.out.println(n.key);
		inOrderHelper(n.right);
	}
	
	public void insert(Key key, Value value) {
		root = insert(root, key, value);
	}
	
	private Node insert(Node n, Key k, Value v) {
		if(n == null)
			return new Node(k, v);
		
		if(n.key.compareTo(k) == 0) //if the key already exist, only update the value
			n.value = v;
		else if(k.compareTo(n.key) < 0) //if the key is smaller
			n.left = insert(n.left, k, v);
		else
			n.right = insert(n.right, k, v);
		return n;
	}
	
	public int size() {
		return size(root);
	}
	
	private int size(Node n) {
		if(n == null)
			return 0;
		return 1 + size(n.left)+ size(n.right);
	}
	
	public boolean isEmpty() {
		return (root == null);
		//return (size == 0);
	}
	
	private class Node {
		private Key key;
		private Value value;
		private Node left;
		private Node right;
		
		public Node(Key key, Value value) {
			this.key = key;
			this.value = value;
			left = null;
			right = null;
		}	
	}
	
}
