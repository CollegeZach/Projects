
public interface StackADT<E> {
	
	//places the element e on top of the stack
	public void push(E e);
	
	//removes the top element and returns it
	public E pop();
	
	//returns true only if stack is empty
	public boolean isEmpty();
	
	//returns the number of elements in the stack
	public int size();
	
	//returns the top element without removing it
	public E peek();
}
