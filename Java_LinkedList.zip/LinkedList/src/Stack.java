
public class Stack<E extends Comparable<E>> implements StackADT<E> {

	private SingleLinkList<E> stack;
	private int size;
	
	public Stack() {
		stack = new SingleLinkList<E>();
		size = 0;
	}
	
	
	@Override
	public void push(E e) {
		stack.add(e, 0);
		size++;
	}

	@Override
	public E pop() {
		if(stack.isEmpty())
			return null;
		else {
			size--;
			return stack.remove(0);
		}
	}

	@Override
	public boolean isEmpty() {
		return size == 0;
	}

	@Override
	public int size() {
		return size;
	}

	@Override
	public E peek() {
		return stack.getHead().getData();
	}
	
}
