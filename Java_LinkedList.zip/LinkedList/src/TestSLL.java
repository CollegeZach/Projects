
public class TestSLL {

	public static void main(String[] args) {
		SingleLinkList<String> myList = new SingleLinkList<String>();
		
		System.out.println(myList.size());
		myList.add("Chickadee");
		myList.add("Robin");
		myList.add("Crow");
		myList.add("Bluebird");
		System.out.println(myList.size());
		System.out.println(myList);
		myList.prepend("Owl");
		System.out.println(myList);

		myList.add("Wren", 4);
		System.out.println(myList);

		myList.add("Blue Jay", 0);
		myList.add("blackbird", 12);
		System.out.println(myList);
		System.out.println(myList.contains("Own"));

		System.out.println(myList.size());
		myList.remove(7);
		System.out.println(myList);
		System.out.println(myList.indexOf("Bluebird"));
		System.out.println(myList.remove("Wren"));
		System.out.println(myList);
		System.out.println(myList.remove("Bluebird"));
		System.out.println(myList);
		System.out.println(myList.remove("Blue Jay"));
		System.out.println(myList);
		System.out.println(myList.remove("bird"));
		System.out.println(myList);
		System.out.println("Sorting");
		//myList.sort();
		System.out.println(myList);
	}

}
