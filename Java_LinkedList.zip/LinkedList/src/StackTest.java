
public class StackTest {
	
	public static void main(String[] args) {
		Stack<String> stack = new Stack<String>();
		
		stack.push("Apple");
		stack.push("Orange");
		stack.push("Banana");
		
		System.out.println(stack.size());
		System.out.println(stack.peek());
		
		while(!stack.isEmpty()) {
			System.out.println(stack.pop());
		}
	}
}
