﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PizzaShop
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        string dbConnection = ConfigurationManager.ConnectionStrings["localhost"].ConnectionString;

        //ArrayList<String> streetNames = new ArrayList<String>();

        ArrayList idType = new ArrayList();
        ArrayList idSize = new ArrayList();
        ArrayList idTopping = new ArrayList();

        public MainWindow()
        {
            InitializeComponent();
            AddSizes();
            AddTypes();
            AddToppings();
        }

        public void AddSizes()
        {
            using (SqlConnection newConnection = new SqlConnection(dbConnection))
            {
                string queryString = "SELECT * FROM dbo.Size";
                SqlCommand command = new SqlCommand(queryString, newConnection);
                newConnection.Open();

                SqlDataReader reader = command.ExecuteReader();

                int i = 1;
                while (reader.Read())
                {
                    // Create a new button for every record in the database
                    Button btn_i = new Button();

                    //Assign the text to the button content
                    btn_i.Content = reader["Size"].ToString();

                    //Assign the id to the button name
                    btn_i.Name = "btn_" + reader["idSize"].ToString();

                    btn_i.Click += showSizes;
                    i++;

                    //Add the button to the stack panel
                    SP_Sizes.Children.Add(btn_i);
                }
            }
        }

        void showSizes(object sender, RoutedEventArgs e)
        {
            double endPrice;
            
            using (SqlConnection newConnection = new SqlConnection(dbConnection))
            {
                Button dynamicButton = (Button)sender;
                var sizeID = dynamicButton.Name.Replace("btn_", "");

                string queryString = "SELECT * FROM dbo.Size WHERE idSize=" + sizeID;
                SqlCommand command = new SqlCommand(queryString, newConnection);
                newConnection.Open();

                SqlDataReader reader = command.ExecuteReader();
                string size = "", price = "";
                char newLine = '\n';

                while (reader.Read())
                {
                    size = reader["Size"].ToString();
                    price = reader["Price"].ToString();

                    endPrice = Convert.ToDouble(price);
                }
                //
                TextBoxOrder.Text = TextBoxOrder.Text + size + newLine;
                TextBoxPrice.Text = TextBoxPrice.Text + newLine;
                LabelMultiplier.Content = price;
                LabelSizes.Content = LabelSizes.Content + sizeID + newLine;
                //
                CanvasSizes.Visibility = Visibility.Hidden;
                CanvasTypes.Visibility = Visibility.Visible;
                CanvasToppings.Visibility = Visibility.Hidden;
                
            }
        }

        public void AddTypes()
        {
            using (SqlConnection newConnection = new SqlConnection(dbConnection))
            {
                string queryString = "SELECT * FROM dbo.Pizza";
                SqlCommand command = new SqlCommand(queryString, newConnection);
                newConnection.Open();

                SqlDataReader reader = command.ExecuteReader();

                int i = 1;
                while (reader.Read())
                {
                    // Create a new button for every record in the database
                    Button btn_i = new Button();

                    //Assign the text to the button content
                    btn_i.Content = reader["Type"].ToString();

                    //Assign the id to the button name
                    btn_i.Name = "btn_" + reader["idPizza"].ToString();

                    btn_i.Click += showTypes;
                    i++;

                    //Add the button to the stack panel
                    SP_Types.Children.Add(btn_i);
                }
            }
        }

        void showTypes(object sender, RoutedEventArgs e)
        {
            double priceMultiplier = Convert.ToDouble(LabelMultiplier.Content);
            double pizzaCost;
            
            decimal costTotal = Convert.ToDecimal(LabelTotal.Content);

            using (SqlConnection newConnection = new SqlConnection(dbConnection))
            {
                Button dynamicButton = (Button)sender;
                var pizzaID = dynamicButton.Name.Replace("btn_", "");

                string queryString = "SELECT * FROM dbo.Pizza WHERE idPizza=" + pizzaID;
                SqlCommand command = new SqlCommand(queryString, newConnection);
                newConnection.Open();

                SqlDataReader reader = command.ExecuteReader();
                string type = "", price = "", stringCost, stringTotal;
                char newLine = '\n';
                double pizzaPrice = 0;

                while (reader.Read())
                {
                    type = reader["Type"].ToString();
                    price = reader["Price"].ToString();

                    pizzaPrice = Convert.ToDouble(price);
                }

                TextBoxOrder.Text = TextBoxOrder.Text + type + newLine;

                pizzaCost = priceMultiplier * pizzaPrice;

                decimal costPizza;
                costPizza = Convert.ToDecimal(pizzaCost);
                costPizza = decimal.Round(costPizza, 2);
                stringCost = Convert.ToString(costPizza);
                TextBoxPrice.Text = TextBoxPrice.Text + "$" + stringCost + newLine;

                costTotal = costTotal + costPizza;
                stringTotal = Convert.ToString(costTotal);
                LabelTotal.Content = stringTotal;

                LabelTypes.Content = LabelTypes.Content + pizzaID + newLine;

                CanvasSizes.Visibility = Visibility.Hidden;
                CanvasTypes.Visibility = Visibility.Hidden;
                CanvasToppings.Visibility = Visibility.Visible;
            }
        }

        public void AddToppings()
        {
            using (SqlConnection newConnection = new SqlConnection(dbConnection))
            {
                string queryString = "SELECT * FROM dbo.Topping";
                SqlCommand command = new SqlCommand(queryString, newConnection);
                newConnection.Open();

                SqlDataReader reader = command.ExecuteReader();

                int i = 1;
                while (reader.Read())
                {
                    // Create a new button for every record in the database
                    Button btn_i = new Button();

                    //Assign the text to the button content
                    btn_i.Content = reader["Topping"].ToString();

                    //Assign the id to the button name
                    btn_i.Name = "btn_" + reader["idTopping"].ToString();

                    btn_i.Click += showToppings;
                    i++;

                    //Add the button to the stack panel
                    SP_Toppings.Children.Add(btn_i);
                }
            }
        }

        void showToppings(object sender, RoutedEventArgs e)
        {
            double endPrice;
            decimal costTotal = Convert.ToDecimal(LabelTotal.Content);

            using (SqlConnection newConnection = new SqlConnection(dbConnection))
            {
                Button dynamicButton = (Button)sender;
                var toppingID = dynamicButton.Name.Replace("btn_", "");

                string queryString = "SELECT * FROM dbo.Topping WHERE idTopping=" + toppingID;
                SqlCommand command = new SqlCommand(queryString, newConnection);
                newConnection.Open();

                SqlDataReader reader = command.ExecuteReader();
                string topping = "", price = "", stringCost, stringPrices;
                char newLine = '\n';

                while (reader.Read())
                {
                    topping = reader["Topping"].ToString();
                    price = reader["Price"].ToString();

                    endPrice = Convert.ToDouble(price);
                }

                TextBoxOrder.Text = TextBoxOrder.Text + topping + newLine;

                decimal costPrice;
                costPrice = Convert.ToDecimal(price);
                costPrice = decimal.Round(costPrice, 2);
                stringCost = Convert.ToString(costPrice);
                TextBoxPrice.Text = TextBoxPrice.Text + "$" + stringCost + newLine;

                costTotal = costTotal + costPrice;
                stringPrices = Convert.ToString(costTotal);
                LabelTotal.Content = stringPrices;

                LabelToppings.Content = LabelToppings.Content + toppingID + newLine;
            }
        }

        private void CT_AnotherClick(object sender, RoutedEventArgs e)
        {
            char newLine = '\n';

            TextBoxOrder.Text = TextBoxOrder.Text + newLine;
            TextBoxPrice.Text = TextBoxPrice.Text + newLine;

            CanvasSizes.Visibility = Visibility.Visible;
            CanvasToppings.Visibility = Visibility.Hidden;
            CanvasInstructions.Visibility = Visibility.Hidden;
        }

        private void CT_InstructionsClick(object sender, RoutedEventArgs e)
        {
            CanvasSizes.Visibility = Visibility.Hidden;
            CanvasToppings.Visibility = Visibility.Hidden;
            CanvasInstructions.Visibility = Visibility.Visible;
        }

        private void CT_CompleteClick(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Order Complete!");
            TextBoxOrder.Text = "";
            TextBoxPrice.Text = "";
            LabelTotal.Content = "0";

            CanvasSizes.Visibility = Visibility.Visible;
            CanvasToppings.Visibility = Visibility.Hidden;
            CanvasInstructions.Visibility = Visibility.Hidden;
        }

        private void CT_DeleteClick(object sender, RoutedEventArgs e)
        {
            TextBoxOrder.Text = "";
            TextBoxPrice.Text = "";
            LabelTotal.Content = "0";

            CanvasSizes.Visibility = Visibility.Visible;
            CanvasToppings.Visibility = Visibility.Hidden;
            CanvasInstructions.Visibility = Visibility.Hidden;
        }

        private void CI_BackClick(object sender, RoutedEventArgs e)
        {
            CanvasSizes.Visibility = Visibility.Hidden;
            CanvasToppings.Visibility = Visibility.Visible;
            CanvasInstructions.Visibility = Visibility.Hidden;
        }

        private void CI_AddClick(object sender, RoutedEventArgs e)
        {
            TextBoxOrder.Text = TextBoxOrder.Text + '\n' + TextboxInstructions.Text + '\n';
            TextboxInstructions.Text = "";
        }

        private void CI_AnotherClick(object sender, RoutedEventArgs e)
        {
            char newLine = '\n';

            TextBoxOrder.Text = TextBoxOrder.Text + newLine;
            TextBoxPrice.Text = TextBoxPrice.Text + newLine;

            CanvasSizes.Visibility = Visibility.Visible;
            CanvasToppings.Visibility = Visibility.Hidden;
            CanvasInstructions.Visibility = Visibility.Hidden;
        }

        private void CI_CompleteClick(object sender, RoutedEventArgs e)
        {
            TextBoxOrder.Text = TextBoxOrder.Text + '\n' + TextboxInstructions.Text + '\n';
            LabelInstructions.Content = TextboxInstructions.Text;

            MessageBox.Show("You order is: " + '\n' + TextBoxOrder.Text + '\n' +" Cost is $" + LabelTotal.Content);
            //
            CanvasSizes.Visibility = Visibility.Visible;
            CanvasToppings.Visibility = Visibility.Hidden;
            CanvasInstructions.Visibility = Visibility.Hidden;
            //---------------------------------------------------------------------------------------------------------------------------------------------------------
            int custID = 2;
            String date = DateTime.Now.ToString("yyyy-MM-dd");
            double total = Convert.ToDouble(LabelTotal.Content); // LabelTotal.Content;
            String instructions = Convert.ToString(LabelInstructions.Content);

            SqlConnection orderConnection = new SqlConnection(dbConnection);
            //ADDS TO DATABASE
            String order = "INSERT INTO [Order] (idCust, PurchaseDate, Total, Instructions) VALUES ('"+ custID + "','" + date + "','" + total + "','" + instructions + "');SELECT SCOPE_IDENTITY()";
            using (SqlCommand addCommand = new SqlCommand(order, orderConnection))
            {
                orderConnection.Open();
                int result = addCommand.ExecuteNonQuery();

                //CHECK ERROR
                if (result < 0)
                {
                    Console.WriteLine("Error inserting data into Database!");
                }
                orderConnection.Close();

                
            }

            //int orderID = Convert.ToInt32(order);

            //---------------------------------------------------------------------------------------------------------------------------------------------------------------------------- 

            idSize.Add(LabelSizes.Content);
            idType.Add(LabelTypes.Content);
            idTopping.Add(Convert.ToInt32(LabelToppings.Content));

            for (int i = 0; i < idType.Count; i++)
            {
                using (SqlConnection pizzaConnection = new SqlConnection(dbConnection))
                {
                    if (pizzaConnection.State == ConnectionState.Closed)
                    {
                        pizzaConnection.Open();
                    }

                    //SqlCommand idOrder = new SqlCommand("Insert into [OrderItem] (idOrder, idPizza, idSize) values (" + orderID + "," + idType[i] + "," + idSize[i] + ");SELECT SCOPE_IDENTITY()", pizzaConnection);

                    SqlCommand command = new SqlCommand("Insert into [OrderItem] (idPizza, idSize) values (" + idType[i] + "," + idSize[i] + ");SELECT SCOPE_IDENTITY()", pizzaConnection);

                    int orderitemID = Convert.ToInt32(idOrder.ExecuteScalar());

                    for (int j = 0; j < idTopping.Count; j++)
                    {
                        string pizza = "INSERT INTO [ToppingItem] (idOrderItem, idTopping) VALUES ('" + orderitemID + "', '" + idTopping[j] + "');";
                        SqlCommand cmd2 = new SqlCommand(pizza, pizzaConnection);
                        cmd2.ExecuteNonQuery();
                    }
                }
            }
            
            TextBoxOrder.Text = "";
            TextBoxPrice.Text = "";
            LabelTotal.Content = "0";
            TextboxInstructions.Text = "";
            //
            LabelSizes.Content = "";
            LabelTypes.Content = "";
            LabelToppings.Content = "";
            LabelInstructions.Content = "";
            LabelMultiplier.Content = "";
        }
    }
}
