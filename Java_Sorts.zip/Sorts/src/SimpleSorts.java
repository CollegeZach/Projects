public class SimpleSorts { 
	
	public static void main(String[] args) {
		//TODO Auto-generated method stub
		int[] A = {3,8,19,2,10,97,90,123,11,54,67};
		
		//bubbleSort(A);
		//selectionSort(A);
		//insertionSort(A);
		//quickSort(A);
		mergeSort(A);
		
		for (int i = 0; i < A.length; i++) {
			System.out.print(A[i] + " ");
		}
	}
		
	//Method uses Bubble sort to sort the given array
	public static void bubbleSort(int[] array) {
	
		boolean swapped = true;
		int temp;
		while(swapped) {
			swapped = false;
			for (int i = 0; i < array.length - 1; i++) {
				if(array[i+1] > array[i]) {
					swapped = true;
					temp = array[i];
					array[i] = array[i+1];
					array[i+1] = temp;
				}
			}
		}
	}
	
	//Method uses Selection sort to sort the given array
	public static void selectionSort(int[] array) {
		for (int i = 0; i < array.length - 1; i++) {
			int min = i;
			for (int j = i+1; j < array.length; j++) {
				if (array[j] < array[min]) {
					min = j;
				}
			}
			
			//Swapping i-th and min-th elements
			int swap = array[i];
			array[i] = array[min];
			array[min] = swap;
		}
	}
	
	//Method uses Insertion sort to sort the given array
	//Nearly sorted is the best case, also the fastest of the three
	public static void insertionSort(int[] array) {
		for (int j = 1; j > array.length; j++) {
			int current = array[j];
			int i = j-1;
			while ((i>-1) && (array[i] > current)) {
				array[i+1] = array[1];
				i--;
			}
			array[i+1] = current;
		}
	}
	
	//Method uses Quick sort to sort the given array
	//Shines with lots of numbers, but not worth with few numbers
	public static void quickSort(int[] array) {
		quickSortHelper(array, 0, array.length-1);
	}
	//Sorting the portion of the array between the low and high position
	private static void quickSortHelper(int[] array, int low, int high) {
		
		int i = low;
		int j = high;
		int mid = (high+low)/2;
		int pivot = array[mid];
		int temp;
		
		while(i <= j) {
			while(array[i] < pivot) {
				i++;
			}
			while(array[j] > pivot) {
				j--;
			}
			if(i <= j) {
				//swap the values
				temp = array[i];
				array[i] = array[j];
				array[j]=temp;
				i++;
				j--;
			}
		}
		
		if(low < j) {
		quickSortHelper(array, low, j);
		}
		if(i < high) {
		quickSortHelper(array, i, high);
		}
	}
		
	
	public static void mergeSort(int[] array) {
		mergeSortHelper(array, 0, array.length-1);
	}
	public static void mergeSortHelper(int[] array, int low, int high) {
		if (high <= low) return;
		
		int mid = (low+high)/2;
		mergeSortHelper(array, low, mid);
		mergeSortHelper(array, mid+1, high);
		//merge(array, low, mid, high);
	}
	
	//Assuming low to mid and mid to high is sorted
	public static void merge(int[] array, int low, int mid, int high) {
		int leftArray[] = new int[mid-low+1];
		int rightArray[] = new int[high-mid];
		
		for (int i = 0; i < leftArray.length; i++)
			leftArray[i] = array[low + i];
		for (int i = 0; i < rightArray.length; i++)
			rightArray[i] = array[mid+i+1];
		
		int leftIndex = 0;
		int rightIndex = 0;
		
		for (int i = low; i < high + 1; i++) {
			if (leftIndex < leftArray.length && rightIndex < rightArray.length) {
				if (leftArray[leftIndex] < rightArray[rightIndex]) {
					array[i] = leftArray[leftIndex];
					leftIndex++;
				} else {
					array[i] = rightArray[rightIndex];
					rightIndex++;
				}
			} else if (leftIndex < leftArray.length) {
				array[i] = leftArray[leftIndex];
				leftIndex++;
			} else if (rightIndex < rightArray.length) {
				array[i] = rightArray[rightIndex];
				rightIndex++;
			}
		}
	}
}