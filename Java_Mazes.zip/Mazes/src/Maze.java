import java.util.Random;
import java.util.Scanner;
import java.util.ArrayList;

public class Maze implements Details{
	private static Spot start;
	private static Spot end;
	
	public static void main(String[] args) {
		/**This creates the maze.**/
		Spot[][] maze = createBoard();
				
		/**This randomly puts a start and end somewhere on the maze.**/
		pickStartEnd(maze);
		/**This prints the maze.**/
		printMaze(maze);
		
		System.out.println();
		
		//solveBFS(maze); /**Handles BFS**/
		solveDFS(maze); /**Handles DFS**/
		
	}
	
	private static Spot[][] createBoard() {
		Spot[][] board = new Spot[ROW][COL];
		for(int row= 0; row < board.length; row++) {
			for(int col = 0; col <board[row].length; col++) {
				if(row == 0 || col == 0) {
					board[row][col] = new Spot(col, row, 0, 'X'); //Top and Left Side
					continue;
				}
				if(row == board.length - 1 || col == board[row].length - 1) {
					board[row][col] = new Spot(col, row, 0, 'X'); //Bottom and Right Side
					continue;
				}
				if(Math.random() < SPOTS) { //Change .25 down the road
					board[row][col] = new Spot(col, row, 0, 'X'); //Inner Walls
				}
				else {
					board[row][col] = new Spot(col, row, 1, ' '); //Empty Sports
				}
			}
		}
		return board;
	}
	
	public static void pickStartEnd(Spot[][] maze) {
		Random rnd = new Random();
		
		int col = rnd.nextInt(COL - 2) + 1;
		int row = rnd.nextInt(ROW - 2) + 1;
		maze[row][col] = start = new Spot(col, row, 5, ' '); //START
		col = rnd.nextInt(COL - 2) + 1;
		row = rnd.nextInt(ROW - 2) + 1;
		maze[row][col] = end = new Spot(col, row, 8, ' '); //END
	}
	
	public static void printMaze(Spot[][] maze) {
		for(int row = 0; row < maze.length; row++) {
			for(int col = 0; col < maze[row].length; col++) {
				System.out.printf("%3d", maze[row][col].data);
			}
			System.out.println("");
		}
	}
		
	private static void solveBFS(Spot[][] maze) {
		boolean finished = false;
		boolean neighbors = false;
		ArrayQueue<Spot> queue = new ArrayQueue<Spot>(ROW * COL);
		ArrayList<Spot> walking = new ArrayList<Spot>();
		Spot current = null;
				
		//System.out.println("Enqueue start point");
		queue.enqueue(start);
		//Scanner keyboard = new Scanner(System.in);
		while(!queue.isEmpty() && !finished) {
			//keyboard.nextLine();
			//pop first
			current = queue.dequeue();
			
			walking.add(current);
			neighbors = false;
						
			if(current == end) {
				finished = true;
			}
			else {
				System.out.print("Dequeueing - ");
				System.out.println(current);
				if(current.type == ' ') {
					current.type = 'H'; //H is Head
				}
				
				if(current.visited) {
					if(current.type == 'H') {
						current.type = ' ';
					}
					//System.out.println("Visited dequeueing point." + current);
					continue;
				}
				//The work
				current.visited = true;
				//System.out.println("current.visited equals true.");
				//Found end condition
				if(current == end) {
					System.out.println("Reached end");
					finished = true;
				}
				
				//System.out.println("Looking for a spot.");
				if(current.row > 1) {
					Spot N = maze[current.row - 1][current.col];
					if(N.isWalkable() && !N.visited) {
						if(N == end) {
							walking.add(N);
							finished = true;
						}
						System.out.println("Enqueueing North");
						queue.enqueue(N);
						neighbors = true;
					}
				}
				
				if(current.row < ROW) {
					Spot S = maze[current.row + 1][current.col];
					if(S.isWalkable() && !S.visited) {
						if(S == end) {
							walking.add(S);
							finished = true;
						}
						System.out.println("Enqueueing South");
						queue.enqueue(S);
						neighbors = true;
					}
				}
				
				if(current.col < COL) {
					Spot E = maze[current.row][current.col + 1];
					if(E.isWalkable() && !E.visited) {
						if(E == end) {
							walking.add(E);
							finished = true;
						}
						System.out.println("Enqueueing East");
						queue.enqueue(E);
						neighbors = true;
					}
				}
				
				if(current.col > 1) {
					Spot W = maze[current.row][current.col - 1];
					if(W.isWalkable() && !W.visited) {
						if(W == end) {
							walking.add(W);
							finished = true;
						}
						System.out.println("Enqueueing West");
						queue.enqueue(W);
						neighbors = true;
					}
				}	
			}
		}
		
		String path = determineSolutions(maze, walking);
		printSolveMaze(maze);
		
		System.out.println("Coordinates for the path.");
		System.out.println(path);
	}
	
	private static void solveDFS(Spot[][] maze) {
		boolean finished = false;
		boolean neighbors = false;
		ArrayStack<Spot> stack = new ArrayStack<Spot>(ROW * COL);
		ArrayList<Spot> walking = new ArrayList<Spot>();
		Spot current = null;
		
		
		//System.out.println("Push start point");
		stack.push(start);
		Scanner keyboard = new Scanner(System.in);
		while(!stack.isEmpty() && !finished) {
			//keyboard.nextLine();
			//pop first
			current = stack.pop();
			
			walking.add(current);
			neighbors = false;
						
			if(current == end) {
				finished = true;
			}
			else {
				System.out.print("Popping - ");
				System.out.println(current);
				if(current.type == ' ') {
					current.type = 'H'; //H is Head
				}
				if(current.visited) {
					if(current.type == 'H') {
						current.type = ' ';
					}
					System.out.println("Visited popped point." + current);
					continue;
				}
			
				//The work
				current.visited = true;
				//System.out.println("current.visited equals true");
				//Found end condition
				
				//System.out.println("Looking for a spot.");
				if(current.row > 1) {
					Spot N = maze[current.row - 1][current.col];
					if(N.isWalkable() && !N.visited) {
						System.out.println("Pushing North");
						stack.push(N);
						neighbors = true;
					}
				}
			
				if(current.row < ROW) {
					Spot S = maze[current.row + 1][current.col];
					if(S.isWalkable() && !S.visited) {
						System.out.println("Pushing South");
						stack.push(S);
						neighbors = true;
					}
				}
			
				if(current.col < COL) {
					Spot E = maze[current.row][current.col + 1];
					if(E.isWalkable() && !E.visited) {
						System.out.println("Pushing East");
						stack.push(E);
						neighbors = true;
					}
				}	
			
				if(current.col > 1) {
					Spot W = maze[current.row][current.col - 1];
					if(W.isWalkable() && !W.visited) {
						System.out.println("Pushing West");
						stack.push(W);
						neighbors = true;
					}
				}
				
				if(!neighbors) {
					walking.remove(current);
				}
			}
			
		}
				
		String path = determineSolutions(maze, walking);
		printSolveMaze(maze);
		
		
		
		if(current != end) {
			System.out.println("Can't reach end!");
			
		}
		else {
			System.out.println("Coordinates for the path.");
			System.out.println(path);
		}
	}
		
	public static String determineSolutions(Spot[][] maze, ArrayList<Spot> walking) {
		String path = "";
		
		for(Spot spot : walking) {
			maze[spot.row][spot.col].type = 'T';
			path += "(" + spot.col + ", " + spot.row + ") ";
		}
		return path;
	}
	
	public static void printSolveMaze(Spot[][] maze) {
		String[][] path = new String[ROW][COL];
		for (int i = 0; i < maze.length; i++) {
			for (int j = 0; j < maze[i].length; j++) {
				path[i][j] = maze[i][j].draw();
			}
		}
		
		for(int row = 0; row < path.length; row++) {
			for(int col = 0; col < path[row].length; col++) {
				System.out.print(path[row][col]);
			}
			System.out.println(" ");
		}
	}
	
}