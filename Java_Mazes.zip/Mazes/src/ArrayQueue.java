
@SuppressWarnings("hiding")
public class ArrayQueue<Spot> {
	//private attrs
		private Spot[] queue;
		private int front;
		private int size;
		
		@SuppressWarnings("unchecked")
		ArrayQueue(int capacity) {
			queue = (Spot[]) new Object[capacity];
			front = 0;
			size = 0;
		}
		
		public int size() {
			return size;
		}
		
		public boolean isEmpty() {
			return size == 0;
		}
		
		public Spot peek() {
			//check if empty
			if(isEmpty()) {
				return null;
			}
			return queue[front];
		}
		
		public void enqueue(Spot obj) {
			//check we have enough capacity
			if(size == queue.length) {
				System.out.println("Queue Overflow");
				return;
			}
			int available = (front + size) % queue.length;
			queue[available] = obj;
			size++;
		}
		
		public Spot dequeue() {
			if(isEmpty()) {
				System.out.println("Can't dequeue from empty queue");
				return null;
			}
			Spot temp = queue[front];
			queue[front] = null;
			front = ++front % queue.length;
			size--;
			return temp;
		}
		
		@Override
		public String toString() {
			StringBuilder sb = new StringBuilder();
			for(int i = 0; i < queue.length; i++) {
				sb.append(queue[i] + ", ");
			}
			return sb.toString();
		}
	}
