public interface Details {
	double SPOTS = .25;
	int ROW = 8;
	int COL = 8;
}