
@SuppressWarnings("hiding")
public class ArrayStack<Spot> {
	private Spot[] stack;
	private int top;
	
	@SuppressWarnings("unchecked")
	ArrayStack(int capacity) {
		stack = (Spot[]) new Object[capacity];
		top = -1;
	}
	
	public int size() {
		return top + 1;
	}
	
	public boolean isEmpty() {
		if(top == -1) {
			return true;
		}
		else {
			return false;
		}
	}
	
	public Spot pop() {
		if(isEmpty()) {
			return null;
		}
		Spot temp = stack[top];
		stack[top--] = null;
		return temp;
	}
	
	public void push(Spot obj) {
		stack[++top] = obj;
	}
	
	public Spot peek() {
		if(isEmpty()) {
			return null;
		}
		return stack[top];
	}
	
	public String toString() {
		String str = "top{";
		for(int i = top; i > -1; i--) {
			str += stack[i] + ", ";
		}
		str = str.substring(0, str.length() - 2);
		str = str + "}bottom";
		return str;
	}
}
