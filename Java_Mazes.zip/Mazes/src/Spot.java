public class Spot {
	public int row;
	public int col;
	public char type;
	public boolean visited;
	public int data;
	
	Spot(int col, int row, int data, char type) {
		this.row = row;
		this.col = col;
		this.type = type;
		this.visited = false;
		this.data = data;
	}
	
	public boolean isWalkable() {
		if(this.type != 'X') {
			return true;
		}
		return false;
	}
	
	public String draw() {
		if(data == 5)
			return "S"; //START
		if(data == 8)
			return "E"; //END
		
		
		if(type == 'T') {
			return "#";
		}
		else if(this.visited) {
			return "*";
		}
		else if(type != ' ') {
			return type+"";
		}
		
		
		return " ";
	}
	
	public String toString() {
		return "row = " + this.row + ", col = " + this.col + ", visited = " + this.visited;
	}
}
