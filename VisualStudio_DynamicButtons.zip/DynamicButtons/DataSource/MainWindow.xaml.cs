﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace DataSource
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        string dbConnection = ConfigurationManager.ConnectionStrings["aws"].ConnectionString;

        public MainWindow()
        {
            InitializeComponent();
            FillDataGrid();
        }

        public void FillDataGrid()
        {
            using (SqlConnection newConnection = new SqlConnection(dbConnection))
            {

                string queryString = "SELECT * FROM Student ORDER BY lastName ASC";
                SqlCommand command = new SqlCommand(queryString, newConnection);
                newConnection.Open();

                SqlDataReader reader = command.ExecuteReader();

                int i = 1;
                while (reader.Read())
                {
                    // Create a new button for every record in the database
                    Button btn_i = new Button();

                    //Assign the text to the button content
                    btn_i.Content = reader["firstName"].ToString();

                    //Assign the id to the button name
                    btn_i.Name = "btn_" + reader["idStudent"].ToString();

                    btn_i.Click += showMessage;
                    i++;

                    // Add the button to the stack panel
                    spButtons.Children.Add(btn_i);
                }
            }
        }

        void showMessage(object sender, RoutedEventArgs e)
        {

            using (SqlConnection newConnection = new SqlConnection(dbConnection))
            {

                Button dynamicButton = (Button)sender;
                var studentID = dynamicButton.Name.Replace("btn_", "");

                string queryString = "SELECT * FROM Student WHERE idStudent = " + studentID;
                SqlCommand command = new SqlCommand(queryString, newConnection);
                newConnection.Open();

                SqlDataReader reader = command.ExecuteReader();
                string firstName = "", lastName = "";

                int i = 1;
                while (reader.Read())
                {
                    firstName = reader["firstName"].ToString();
                    lastName = reader["lastName"].ToString();
                }

                MessageBox.Show(firstName + " " + lastName);
            }
        }
    }
}
