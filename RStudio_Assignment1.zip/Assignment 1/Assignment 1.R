install.packages("ggplot2")
install.packages("tidyr")
install.packages("dplyr")
install.packages("glmnet")
install.packages("Rcpp")
install.packages("knitr")
install.packages("coefplot")
install.packages("useful")
install.packages("resumer")

install.packages("htmltab")
install.packages("rvest")
install.packages("RCurl")
install.packages("rlist")
install.packages("data.table")
install.packages("readxl")
install.packages("xlsx")
install.packages("tidyverse")
install.packages("readxl")



library(devtols)



#PROBLEM ONE

library(RCurl)
library(rlist)
library(XML)

url <- "https://emergency.cdc.gov/han/han00384.asp"
theURL <- getURL(url)
#theURL <- getURL("https://emergency.cdc.gov/han/han00384.asp", .opts=list(ssl.verifypeer=FALSE))
temp <- readHTMLTable(theURL, which=1, header=FALSE, stringAsFactors=FALSE)
dfdata = data.frame(temp)
hold <- strtoi(dfdata[2:nrow(dfdata),3])
#the states with the most number of Fentanyl seizures
sprintf("%.1f", max(hold))
#the states with the least number of Fentanyl seizures
sprintf("%.1f", min(hold))



#PROBLEM TWO

#library("data.table")
hurricane <- read.csv("https://people.sc.fsu.edu/~jburkardt/data/csv/hurricanes.csv")
#head(hurricane)
#hurricane
hurricaneDF <- data.frame(hurricane)
hurricaneTemp <- hurricaneDF

#Getting Average Before 2010
before2010 <- hurricaneDF[,3:7]
before2010$AverMonth <- rowMeans(before2010)
#AverageBefore2010

#Getting Average After 2010
after2010 <- hurricaneDF[,8:ncol(hurricaneDF)]
after2010$AverMonth2 <- rowMeans(after2010)
#AverageAfter2010

#Adding Columns
hurricaneTemp$AvgB2010 <- before2010[,ncol(before2010)]
hurricaneTemp$AvgA2010 <- after2010[,ncol(after2010)]
hurricaneDF <- hurricaneTemp
#theDF

#Creating Chart
require(ggplot2)
library(ggplot2)
require(scales)

hurricaneGraph <- ggplot(hurricaneDF, aes(x = Month)) + geom_line(aes(y = AvgB2010, color = "Before 2010" ,group = 1)) + geom_point(aes(y = AvgB2010)) + geom_line(aes(y = AvgA2010, color = "After 2010" ,group = 1)) + geom_point(aes(y = AvgA2010))
hurricaneGraph <- hurricaneGraph + labs(x = "Month", y = "Hurricane Averages", title = "Hurricanes Before/After 2010")
hurricaneGraph



#PROBLEM THREE

require(xlsx)
library(tidyverse)
library(readxl)
library(data.table)

#A) Reading Data
overdose_data <- read_excel("overdose_data_1999-2015.xlsx", sheet = "Online", na = "---")
#View(overdose_data)
overdoseTable <- data.frame(overdose_data)

#B) Cleaning Data
overdoseTable <- drop_na(overdoseTable)
colnames(overdoseTable) <- c("Title", 1999:2015)
#overdoseTable

#C) All Deaths
dfPartC <- overdoseTable[c(0, 2, 3), c(5:18)]
dfPartC
Year <- c(2002:2015)
dfPartC[nrow(dfPartC) + 1,] <- Year
newPartC <- t(dfPartC)
colnames(newPartC) <- c("Female","Male","Year")
newPartC <- data.frame(newPartC)

graphC <- ggplot(newPartC,aes(x = Year)) + geom_point(aes(y = Female, color = "Female")) + geom_point(aes(y = Male, color = "Male"))
graphC <- graphC + labs(x = "Year", y = "Overdose Deaths", title = "All Drug Deaths.")
graphC

#D) Opioid Pain Reliever Deaths

dfPartD <- overdoseTable[c(0, 8, 9), c(5:18)]
dfPartD[nrow(dfPartD) + 1,] <- Year
newPartD <- t(dfPartD)
colnames(newPartD) <- c("Female","Male","Year")
newPartD <- data.frame(newPartD)

graphD <- ggplot(newPartD,aes(x = Year)) + geom_point(aes(y = Female, color = "Female")) + geom_point(aes(y = Male, color = "Male"))
graphD <- graphD + labs(x = "Year", y = "Overdose Deaths", title = "Opioid Pain Reliever Deaths")
graphD

#E)Heroin Deaths

dfPartE <- overdoseTable[c(0, 20, 21), c(5:18)]
dfPartE[nrow(dfPartE) + 1,] <- Year
newPartE <- t(dfPartE)
colnames(newPartE) <- c("Female","Male","Year")
newPartE <- data.frame(newPartE)

graphE <- ggplot(newPartE,aes(x = Year)) + geom_point(aes(y = Female, color = "Female")) + geom_point(aes(y = Male, color = "Male"))
graphE <- graphE + labs(x = "Year", y = "Overdose Deaths", title = "Heroin Deaths")
graphE
