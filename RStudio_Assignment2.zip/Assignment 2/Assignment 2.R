library(dplyr)
library(ggplot2)
library(data.table)
library(tidyverse)

#Question 1
mtcars
cars <- data.frame(mtcars)

#Part A
highestHP <- data.frame()
highestHP <- mtcars[order(mtcars$hp, decreasing = TRUE), ]
head(highestHP,1)

#Part B
theCylinders <- mtcars[, c("cyl", "hp")]

hp4cyl <- theCylinders[theCylinders$cyl == 4,]
hp6cyl <- theCylinders[theCylinders$cyl == 6,]
hp8cyl <- theCylinders[theCylinders$cyl == 8,]

avg4cyl <- mean(HP4cyl$hp)
avg6cyl <- mean(HP6cyl$hp)
avg8cyl <- mean(HP8cyl$hp)

avg4cyl
avg6cyl
avg8cyl

#Part C
totalAutomatic <- sum(mtcars$am == "1")
totalAutomatic
totalManual <- sum(mtcars$am == "0")
totalManual

#Part D
new4cyl <- cbind(HP4cyl, Avg4cyl)
new6cyl <- cbind(HP6cyl, Avg6cyl)
new8cyl <- cbind(HP8cyl, Avg8cyl)

colnames(new4cyl) <- c("cyl", "hp", "mean")
colnames(new6cyl) <- c("cyl", "hp", "mean")
colnames(new8cyl) <- c("cyl", "hp", "mean")

totalCyl <- rbind(new4cyl, new6cyl, new8cyl)
totalCyl

graphCyl <- ggplot(Totalcyl, aes(x = cylinder, y = HorsePower)) + geom_point(aes(y = mean, x = cyl))
graphCyl

#Part E
automaticCars <- mtcars[mtcars$am == "1",]
automaticCars <- automaticCars[c("mpg", "hp", "am")]

graphAutomatic <- ggplot(automaticCars, aes(x = MPG, y = HP)) + geom_point(aes(x = mpg, y = hp))
graphAutomatic

manualCars <- mtcars[mtcars$am == "0",]
manualCars <- manualCars[c("mpg", "hp", "am")]

graphManual <- ggplot(manualCars, aes(x = MPG, y = HP)) + geom_point(aes(x = mpg, y = hp))
graphManual



#Question 2
randomNumbers <- round(runif(n = 20, min = -10, max = 10), digits = 0)
randomNumbers

randomMatrix <- matrix(randomNumbers, nrow = 4, ncol = 5, byrow = TRUE)
randomMatrix

randomMean <- mean(randomNumbers)
randomMean

#Part A
clockwiseMatrix <- randomMatrix
rotate <- t(apply(clockwiseMatrix, 2, rev))
rotate

#Part B
counterclockwiseMatrix <- randomMatrix
rotate <- t(apply(counterclockwiseMatrix, 2, rev))
rotate <- t(apply(rotate, 2, rev))
rotate <- t(apply(rotate, 2, rev))
rotate

#Part C
meanMatrix <- randomMatrix
meanMatrix[meanMatrix < randomMean] <- -1
meanMatrix[meanMatrix = randomMean] <- 0
meanMatrix[meanMatrix > randomMean] <- 1
meanMatrix



#Question 3

#Part 1
pd0.5 <- rpois(n = 1000, lambda = 0.5)
pd0.5

pd1 <- rpois(n = 1000, lambda = 1.0)
pd1

pd1.5 <- rpois(n = 1000, lambda = 1.5)
pd1.5

pd2 <- rpois(n = 1000, lambda = 2.0)
pd2

pd2.5 <- rpois(n = 1000, lambda = 2.5)
pd2.5

#Part 2
pd <- cbind(pd0.5, pd1, pd1.5, pd2, pd2.5)
temp <- seq(0, 9, by = 1)
numbers <- cut(pd, temp)
table(numbers)
organize <- table(numbers)
organize <- as.data.frame(organize)
t(organize)
class(organize)

#Part 3
results <- ggplot(organize, aes(x = Numbers, y = Frequency)) + geom_point(aes(y = Freq, x = numbers))
results
