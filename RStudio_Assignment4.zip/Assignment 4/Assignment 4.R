#Install
install.packages("tm")
install.packages("SnowballC")
install.packages("wordcloud")
install.packages("wordcloud2")
install.packages("RColorBrewer")
install.packages("syuzhet")
install.packages("ggplot2")
install.packages("readtext")

#Load
library("tm")
library("SnowballC")
library("wordcloud")
library("wordcloud2")
library("RColorBrewer")
library("syuzhet")
library("ggplot2")
library("dplyr")
library("tidytext")
library("igraph")
library("ggraph")
library("twitteR")
library("plotly")
library("stringr")


inflationTweets <- readRDS(file = "inflation_tweets")
inflationTweets_DF <- twListToDF(inflationTweets)

sampleTweets1 <- readRDS(file = "sample_tweets1")
sampleTweets1_DF <- twListToDF(sampleTweets1)

sampleTweets2 <- readRDS(file = "sample_tweets2")
sampleTweets2_DF <- twListToDF(sampleTweets2)

options(stringsAsFactors = FALSE)
require(quanteda)



cleanText <- inflationTweets_DF$text
inflationTweets_Corpus <- Corpus(VectorSource(cleanText))

inflationTweets_Corpus <- tolower(inflationTweets_Corpus)
inflationTweets_Corpus <- removeNumbers(inflationTweets_Corpus)
inflationTweets_Corpus <- removeWords(inflationTweets_Corpus, stopwords())
inflationTweets_Corpus <- removePunctuation(inflationTweets_Corpus)
inflationTweets_Corpus <- paste(str_extract_all(inflationTweets_Corpus, '\\w{4,}')[[1]], collapse = ' ')
#inflationTweets_Corpus <- gsub('\\b\\w{3}\\b','',inflationTweets_Corpus)

#filter and numchar keep if >3

DTM <- dfm(inflationTweets_Corpus)
freqs <- colSums(DTM)
words <- colnames(DTM)
wordlist <- data.frame(words, freqs)
wordIndexes <- order(wordlist[, "freqs"], decreasing = TRUE)
wordlist <- wordlist[wordIndexes, ]
#head(wordlist, 25)

#Word Cloud
set.seed(783)
wordcloud(words = wordlist$word, freq = wordlist$freq, min.freq = 1, max.words = 200, random.order = FALSE, rot.per=0.35, colors = brewer.pal(8, "Dark2"))



cleanText <- sampleTweets1_DF$text
sampleTweets1_Corpus <- Corpus(VectorSource(cleanText))

sampleTweets1_Corpus <- tolower(sampleTweets1_Corpus)
sampleTweets1_Corpus <- removeNumbers(sampleTweets1_Corpus)
sampleTweets1_Corpus <- removeWords(sampleTweets1_Corpus, stopwords())
sampleTweets1_Corpus <- removePunctuation(sampleTweets1_Corpus)
sampleTweets1_Corpus <- paste(str_extract_all(sampleTweets1_Corpus, '\\w{4,}')[[1]], collapse = ' ')

DTM <- dfm(sampleTweets1_Corpus)
freqs <- colSums(DTM)
words <- colnames(DTM)
wordlist <- data.frame(words, freqs)
wordIndexes <- order(wordlist[, "freqs"], decreasing = TRUE)
wordlist <- wordlist[wordIndexes, ]
#head(wordlist, 25)

#Word Cloud
set.seed(783)
wordcloud(words = wordlist$word, freq = wordlist$freq, min.freq = 1, max.words = 200, random.order = FALSE, rot.per=0.35, colors = brewer.pal(8, "Dark2"))



cleanText <- sampleTweets2_DF$text
sampleTweets2_Corpus <- Corpus(VectorSource(cleanText))

sampleTweets2_Corpus <- tolower(sampleTweets2_Corpus)
sampleTweets2_Corpus <- removeNumbers(sampleTweets2_Corpus)
sampleTweets2_Corpus <- removeWords(sampleTweets2_Corpus, stopwords())
sampleTweets2_Corpus <- removePunctuation(sampleTweets2_Corpus)
sampleTweets2_Corpus <- paste(str_extract_all(sampleTweets2_Corpus, '\\w{4,}')[[1]], collapse = ' ')

DTM <- dfm(sampleTweets2_Corpus)
freqs <- colSums(DTM)
words <- colnames(DTM)
wordlist <- data.frame(words, freqs)
wordIndexes <- order(wordlist[, "freqs"], decreasing = TRUE)
wordlist <- wordlist[wordIndexes, ]
#head(wordlist, 25)

#Word Cloud
set.seed(783)
wordcloud(words = wordlist$word, freq = wordlist$freq, min.freq = 1, max.words = 200, random.order = FALSE, rot.per=0.35, colors = brewer.pal(8, "Dark2"))



#NRC
get_sentiment("nrc")

#NRC <- get_sentiment(inflationTweets_Corpus, method = "nrc")

#sentiments <- data.frame(NRC)
NRC <- get_nrc_sentiment(inflationTweets_Corpus)
#emotions

NRC_Col = colSums(NRC)
NRC_DF = data.frame(count = NRC_Col, feelings = names(NRC_Col))
NRC_DF$feelings = factor(NRC_DF$feelings, levels = NRC_DF$feelings[order(NRC_DF$count, decreasing = TRUE)])

plot_ly(NRC_DF, x=~feelings, y=~count, type = "bar", color=~feelings) %>%
  layout(xaxis=list(title=""), showlegend=FALSE, title="NRC Lexicon")

