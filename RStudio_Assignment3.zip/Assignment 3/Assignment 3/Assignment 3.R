#This fixes 1.0.5 is already loaded, but >= 1.0.6. is required
#remove.packages("rlang")
#install.packages("rlang")

#Install
install.packages("tm")
install.packages("SnowballC")
install.packages("wordcloud")
install.packages("wordcloud2")
install.packages("RColorBrewer")
install.packages("syuzhet")
install.packages("ggplot2")
install.packages("readtext")

#Load
library("tm")
library("SnowballC")
library("wordcloud")
library("wordcloud2")
library("RColorBrewer")
library("syuzhet")
library("ggplot2")
library("dplyr")
library("tidytext")
library("igraph")
library("ggraph")



#Problem 1
data_files <- list.files(path = "Winston Chruchill 1941 - 1949", full.names = T, recursive = T)

require(readtext)
extracted_texts <- readtext(data_files, docvarsfrom = "filepaths", dvsep = "/")

options(stringsAsFactors = FALSE)

require(quanteda)
files_corpus <- corpus(extracted_texts$text, docnames = extracted_texts$doc_id)
#summary(files_corpus)

files_corpus <- removePunctuation(files_corpus)
files_corpus <- tolower(files_corpus)
files_corpus <- removeNumbers(files_corpus)
files_corpus <- removeWords(files_corpus, stopwords())

DTM <- dfm(files_corpus)
freqs <- colSums(DTM)
words <- colnames(DTM)
wordlist <- data.frame(words, freqs)
wordIndexes <- order(wordlist[, "freqs"], decreasing = TRUE)
wordlist <- wordlist[wordIndexes, ]
head(wordlist, 25)



#Word Cloud
set.seed(783)
wordcloud(words = wordlist$word, freq = wordlist$freq, min.freq = 1, max.words = 200, random.order = FALSE, rot.per=0.35, colors = brewer.pal(8, "Dark2"))

#Histogram
barplot(wordlist[1:20,]$freq, las = 2, names.arg = wordlist[1:20,]$word, col = "lightgreen", main = "Top 20 Most Frequent Words", ylab = "Word Frequencies")

#Top 100 words
clean_corpus <- Corpus(VectorSource(files_corpus))
TextDoc_tdm <- TermDocumentMatrix(clean_corpus)
findAssocs(TextDoc_tdm, terms = c("war" ,"peace"), corlimit = 0.50)




#Problem 2
part1_files <- list.files(path = "SCOTUS_2021_Part_1", full.names = T, recursive = T)
part2_files <- list.files(path = "SCOTUS_2021_Part_2", full.names = T, recursive = T)


require(readtext)
part1_extracted <- readtext(part1_files, docvarsfrom = "filepaths", dvsep = "/")
part2_extracted <- readtext(part2_files, docvarsfrom = "filepaths", dvsep = "/")

options(stringsAsFactors = FALSE)

require(quanteda)
part1_corpus <- corpus(part1_extracted$text, docnames = part2_extracted$doc_id)
part2_corpus <- corpus(part2_extracted$text, docnames = part2_extracted$doc_id)
#summary(files_corpus)

part1_corpus <- removePunctuation(part1_corpus)
part1_corpus <- tolower(part1_corpus)
part1_corpus <- removeNumbers(part1_corpus)
part1_corpus <- removeWords(part1_corpus, stopwords())

part2_corpus <- removePunctuation(part2_corpus)
part2_corpus <- tolower(part2_corpus)
part2_corpus <- removeNumbers(part2_corpus)
part2_corpus <- removeWords(part2_corpus, stopwords())

part1_DTM <- dfm(part1_corpus)
part1_freqs <- colSums(part1_DTM)
part1_words <- colnames(part1_DTM)
part1_wordlist <- data.frame(part1_words, part1_freqs)
part1_wordIndexes <- order(part1_wordlist[, "part1_freqs"], decreasing = TRUE)
part1_wordlist <- wordlist[part1_wordIndexes, ]
#head(part1_wordlist, 25)

part2_DTM <- dfm(part2_corpus)
part2_freqs <- colSums(part2_DTM)
part2_words <- colnames(part2_DTM)
part2_wordlist <- data.frame(part2_words, part2_freqs)
part2_wordIndexes <- order(part2_wordlist[, "part2_freqs"], decreasing = TRUE)
part2_wordlist <- wordlist[part2_wordIndexes, ]
#head(part2_wordlist, 25)



#Word Cloud
set.seed(783)
wordcloud(words = part1_wordlist$word, freq = wordlist$freq, min.freq = 1, max.words = 200, random.order = FALSE, rot.per=0.35, colors = brewer.pal(8, "Dark2"))
set.seed(783)
wordcloud(words = part2_wordlist$word, freq = wordlist$freq, min.freq = 1, max.words = 200, random.order = FALSE, rot.per=0.35, colors = brewer.pal(8, "Dark2"))

#Histogram
barplot(part1_wordlist[1:20,]$freq, las = 2, names.arg = part1_wordlist[1:20,]$word, col = "lightgreen", main = "Top 20 Most Frequent Words for Part 1", ylab = "Word Frequencies")
barplot(part2_wordlist[1:20,]$freq, las = 2, names.arg = part2_wordlist[1:20,]$word, col = "lightgreen", main = "Top 20 Most Frequent Words for Part 2", ylab = "Word Frequencies")

#Bing
part1_bing <- get_sentiment(part1_extracted, method = "bing")
#part1_bing

part2_bing <- get_sentiment(part2_extracted, method = "bing")
#part2_bing

barplot(part1_bing, las = 2, col = "lightgreen", main = "Bing Lexicon Part 1", ylab = "Ratings")
barplot(part2_bing, las = 2, col = "lightgreen", main = "Bing Lexicon Part 2", ylab = "Ratings")
