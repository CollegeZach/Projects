﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace BinaryCalculator
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        int total;
        Random randomNumber = new Random();
        int randomInt;

        public MainWindow()
        {
            InitializeComponent();

        }

        private void startGame(object sender, RoutedEventArgs e)
        {
            //generate random number and enable check button
            randomInt = randomNumber.Next(0, 511);
            lblNumber.Content = randomInt;
            btnCheck.IsEnabled = true;

            //reset all textboxes to 0
            foreach(var x in wrpButtons.Children.OfType<Button>())
            {
                x.Content = "0";
            }
        }

        private void btnCheck_Click(object sender, RoutedEventArgs e)
        {
            total = 0;

            //loop through all textboxes and use the TAG property
            foreach(var x in wrpButtons.Children.OfType<Button>())
            {
                if(x.Content.Equals(1))
                {
                    total += Convert.ToInt32(x.Tag);
                }
            }
            if(total == randomInt)
            {
                MessageBox.Show("You Win!");
            }
            else
            {
                MessageBox.Show("Baka!");
            }
        }
    }
}
