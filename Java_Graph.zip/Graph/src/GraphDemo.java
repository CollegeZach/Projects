import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;

public class GraphDemo {

	public static void main(String[] args) throws FileNotFoundException {
		WDGraph<String> graph = new WDGraph<String>();
		ArrayList<double[]> coord = new ArrayList<double[]>(); 
		ArrayList<String> streetNames = new ArrayList<String>();
		
		
		File file = new File("map.dat"); //This opens the file
		Scanner infile = new Scanner(file);
		int nodes = infile.nextInt(); //determines how many times to do the for loop
		infile.nextLine(); //reading and ignoring the first line of the file
		
		String aPoint, aLongitude, aLatitude, aHeight, locationName;
		int point;
		double longitude, latitude, height;
		
		for(int i = 0; i < nodes; i++) {
			String line = infile.nextLine();
            String[] information = line.split(",");
            aPoint = information[0];
            aLongitude = information[1];
            aLatitude = information[2];
            aHeight = information[3];
            locationName = information[4];
            //converts the required strings to numbers
            point = Integer.parseInt(aPoint);
            longitude = Double.parseDouble(aLongitude);
            latitude = Double.parseDouble(aLatitude);
            height = Double.parseDouble(aHeight);
            
            graph.addVertex(aPoint);
            double[] latlong = {latitude, longitude};
            coord.add(latlong);
            
            streetNames.add(locationName);
		}
		//System.out.println();
		
		int edges = infile.nextInt();
		String aNode1, aNode2, aBidirectional;
		int node1, node2, bidirectional;
		infile.nextLine();
		for(int i = 0; i < edges; i++) {
			String line = infile.nextLine();
            String[] information = line.split(" ");
            
            aNode1 = information[0]; //lon
            aNode2 = information[1]; //lat
            aBidirectional = information[2];
            //converts the required strings to numbers
            node1 = Integer.parseInt(aNode1); //lon
            node2 = Integer.parseInt(aNode2); //lat
            bidirectional = Integer.parseInt(aBidirectional);
            
            double[] firstNode = coord.get(node1);
            double[] secondNode = coord.get(node2);
                        
            double distance = calcDistance(firstNode[0], firstNode[1], secondNode[0], secondNode[1]);
            
            //System.out.println(distance);
            
            if(bidirectional == 2) {
            	graph.addEdge(aNode1, aNode2, distance);
            	graph.addEdge(aNode2, aNode1, distance);
            }
            else {
            	graph.addEdge(aNode1, aNode2, distance);
            }
		}
		
		//System.out.println("Distance is in meters.");
		System.out.println(graph);
		
		int paths = infile.nextInt();
		String aStart, aEnd;
		//int start, end;
		infile.nextLine();
		
		PrintStream theWay = new PrintStream(new File("directions.dat"));
		
		for(int i = 0; i < paths; i++) {
			String line = infile.nextLine();
            String[] information = line.split(" ");
            
            aStart = information[0];
            aEnd = information[1];
            //converts the required strings to numbers
            //start = Integer.parseInt(aStart);
            //end = Integer.parseInt(aEnd);
            
            ArrayList<String> path = graph.shortestPath(aStart, aEnd);
            
            System.out.println();
            System.out.println(path.toString());
            System.out.println("Start");
            
            String directions = "";
            int vertices = 0;
            for (String string : path) {
            	System.out.println(string + " " + streetNames.get(Integer.parseInt(string)));
            	directions = directions + streetNames.get(Integer.parseInt(string)) + " then ";
            	vertices++;
            }
            
            double totalDistance = 0;
            for (int j = 1; j < vertices; j++) {
            	double[] firstNode = coord.get(j - 1);
                double[] secondNode = coord.get(j);
                
                totalDistance += calcDistance(firstNode[0], firstNode[1], secondNode[0], secondNode[1]);
            }
            String finalDistance = String.format("%.2f", totalDistance);
            System.out.println("Total Distance is " + finalDistance +" km.");
            
            System.out.println("End");
            String route = "Start at " + directions + "you have reached your destination with a distance of " + finalDistance + " km.";
            
            PrintStream console = System.out;
            System.setOut(theWay);
            System.out.println(route);
            
            System.setOut(console);
            System.out.println(route);
		}
	}
	
	//equations to convert to meters is thanks to stack overflow.
	//https://stackoverflow.com/questions/365826/calculate-distance-between-2-gps-coordinates
	private static double calcDistance(double lat1, double lon1, double lat2, double lon2) {
		double r = 6371; //radius of the Earth
        
		double dLat = degreesToRadians(lat2-lat1);
		double dLon = degreesToRadians(lon2-lon1);
		
		lat1 = degreesToRadians(lat1);
		lat2 = degreesToRadians(lat2);

		double a = Math.sin(dLat/2) * Math.sin(dLat/2) +
		          Math.sin(dLon/2) * Math.sin(dLon/2) * Math.cos(lat1) * Math.cos(lat2); 
		double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a)); 
		return r * c;
	}
	
	private static double degreesToRadians(double degrees) {
		  return degrees * Math.PI / 180;
	}
	
}
