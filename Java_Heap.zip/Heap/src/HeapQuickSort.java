import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class HeapQuickSort {	
	
	public static void main(String[] args) {
		long startTime, estimatedTime;
		String[] array = readFile();
		ArrayList<String> newArray = new ArrayList<>(); 
		
		for(int i = 0; i < array.length; i++) {
			if(array[i] != null) {
				newArray.add(array[i]);
			}
		}
				
		String[] heapArray = new String[newArray.size()];
		String[] quickArray = new String[newArray.size()];
		for (int i = 0; i < newArray.size(); i++)
		{
			heapArray[i] = newArray.get(i);
			quickArray[i] = newArray.get(i);
		}
				
		//Heap Sort
		startTime = System.nanoTime();
		heapSort(heapArray);
		prints(heapArray);
		estimatedTime = System.nanoTime() - startTime;
		System.out.println("Heap Sort took " + estimatedTime + " nano seconds.");
				
		
		System.out.println();
		
		//Quick sort
		startTime = System.nanoTime();
		quickSort(quickArray);
		prints(quickArray);
		estimatedTime = System.nanoTime() - startTime;
		System.out.println("Quick Sort took " + estimatedTime + " nano seconds.");
	}
	
	public static String[] readFile() {
		try {
			int countLines = 0;
			int countNames = 0;
			
			BufferedReader countFile = new BufferedReader(new FileReader("names.csv"));
			countFile.readLine();	
			while (countFile.readLine() != null) {
				countLines++;
			}
			
			String[] names = new String[countLines * 3];
			
			BufferedReader readFile = new BufferedReader(new FileReader("names.csv"));
			String readRow;
			readFile.readLine();
			while ((readRow = readFile.readLine()) != null) {
				String[] words = readRow.split(",");
				for(int i = 1; i < words.length; i++) {
					if (!words[i].equals("")) {
						names[countNames] = words[i];
						countNames++;
					}
				}
			}
			readFile.close();
			return names;
		}
		catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	//Heap sort
	private static void heapSort(String[] array) {
		MaxHeap<String> heap = new MaxHeap<String>();
		
		for(int i = 0; i < array.length; i++) {
			if(array[i] != null) {
				heap.insert(array[i]);
			}
		}
		
		for(int j = 0; j < array.length; j++) {
			array[(array.length - 1) - j] = heap.remove();
		}
	}
	
	//Quick sort
	public static void quickSort(String[] array) {
		quickSortHelper(array, 0, array.length-1);	
	}
	private static void quickSortHelper(String[] array, int start, int end) {
		int i = start;
        int j = end;
        
        if (j - i >= 1) {
            String pivot = array[i];
            while (j > i) {
                while (array[i].compareTo(pivot) <= 0 && i < end && j > i) {
                    i++;
                }
                while (array[j].compareTo(pivot) >= 0 && j > start && j >= i) {
                    j--;
                }
                if (j > i) {
                    swap(array, i, j);
                }
            }
            swap(array, start, j);
            quickSortHelper(array, start, j - 1);
            quickSortHelper(array, j + 1, end);
        }
	}	
	private static void swap(String[] array, int i, int j) {
		String temp = array[i];
		array[i] = array[j];
		array[j] = temp;
	}
	
	//Prints
	private static void prints(String[] array) {
		for(int i = 0; i < array.length; i++) {
			System.out.print(array[i] + " ");
		}
		System.out.println("");
	}
}